# Persona and mode playbooks

## Recommended cold-call opener templates

### Controller - direct line
Good afternoon [Name], this is Lewis with Nodal Point. I was hoping you could help me out for a moment.

I’m not totally sure if you’re the right person, but I’m trying to reach whoever looks at possible hidden gaps in your electricity agreement or bill structure that might be causing costs to creep up more than they should.

Would that usually fall under you, or someone else on your team?

### Controller - research-led version
Good afternoon [Name], this is Lewis with Nodal Point. I was hoping you could help me out for a moment.

I saw [expansion / new site / growth cue], and usually when companies are growing like that, energy costs get a little less straightforward than they look on the surface.

I’m not sure if that falls under you, but who usually looks at whether the bill and agreement structure still fit the operation?

### Facilities manager
Hi [Name], this is Lewis with Nodal Point. Quick favor.

I’m not sure if you’re the right person, but I’m trying to figure out who looks at whether the way your site runs is creating electricity costs that the current agreement does not account for very well.

Is that something you ever get pulled into?

### CFO
Hi [Name], Lewis with Nodal Point. I know I caught you out of the blue.

Real quick, I’m trying to find out who on your side keeps an eye on hidden electricity cost drivers before renewal decisions get made, especially anything that can create budget surprises later.

Would that sit with you, finance, or someone else?

## Objection rewrites

### We already have a broker
That makes sense. Most companies I speak with do.

I’m curious, does your broker typically just shop the rate, or do they also help you dig into the other line items that tend to cause costs to creep up, like delivery structure, demand-related spikes, and renewal risk?

[If they seem open]
And do you happen to know when the current agreement expires?

### We’re locked in
Totally fair.

When does that agreement expire?

[If they do not know]
Got it. So part of the challenge is you may not know yet how much room you actually have to plan ahead before renewal, right?

What we usually do in that situation is review the current setup early so you are not forced into a last-minute decision later. Would a quick look be unreasonable?

### Not interested
No problem.

Usually when people say that, it means one of three things: they already reviewed it recently, the timing is bad, or they have not seen anything on the bill that feels worth digging into.

Which one is it for you?

### We have other priorities
I get that.

Is energy just lower on the list right now, or do you feel like there probably is not enough there to justify a look anyway?

### Send me something
Happy to.

Just so I do not send you generic fluff, what would be more relevant to you: a quick note on hidden bill charges, renewal strategy, or how we review demand-related cost issues?

## Discovery questions by stage

### Controller
1. Walk me through how you currently review electricity spend.
2. How much visibility do you feel like you have into what is actually driving the total cost each month?
3. What tends to be the most frustrating part of the bill from your side?
4. Have you had any months recently where the total landed differently than expected?
5. What usually causes that?
6. How are you handling renewal planning today?
7. What happens if nothing changes before the next contract window?
8. How important is it to get clearer on that before you are up against a deadline?

### Facilities manager
1. How does the site typically run during peak periods?
2. When you look at summer bills, where do the spikes tend to show up?
3. What do you think is driving that?
4. Has anything about the schedule, footprint, or equipment changed recently?
5. How well do you feel like the current agreement matches the way the building actually operates?
6. What happens operationally when those charges hit harder than expected?
7. If nothing changes, what does that mean through the next hot season?

### CFO
1. How do you think about electricity costs today from a planning standpoint?
2. Where do you feel most exposed: price, structure, timing, or surprise line items?
3. How much confidence do you have in the current agreement strategy?
4. What would you want more control over if you could?
5. What usually happens if the team waits too long before renewal?
6. If the current setup is not as tight as it should be, what does that mean for budget confidence?

## Contract walkthrough close

Use this shape:
1. restate why they engaged
2. tie the contract structure back to those goals
3. check agreement every few minutes
4. surface remaining concerns before the final ask
5. make the close sound like the natural next step

Example close:
Based on what you told me, the big goals were more visibility, fewer surprise charges, and not getting caught flat-footed at renewal.

This structure is designed around that. We cleaned up the pricing side, we addressed the parts that were creating risk, and we have a path from here so you are not reacting later.

How is this looking so far from your side?

[after discussion]

Is there anything you would want to address before we move forward and get this in place?

[if no major concern]
Then the easiest next step is to get this executed so we can lock the process in and start the review cadence. Are you comfortable moving ahead?
