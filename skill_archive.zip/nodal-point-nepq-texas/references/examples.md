# Example prompts and expected outputs

## Example prompt
Give me a cold calling script for the controller at ABC Manufacturing.

## Expected output shape
- research assumptions
- best opener
- alternate opener
- likely early objections
- how to respond
- meeting ask
- voicemail

## Example prompt
Give me common objections and how to handle them.

## Expected output shape
For each objection:
- what it usually means
- validate line
- clarifying question
- problem-expansion question
- low-pressure next step

## Example prompt
Give me a script flow for a discovery call to help me close the sale.

## Expected output shape
- status frame
- situation questions
- problem-awareness questions
- probing questions
- impact questions
- transition line
- meeting close

## Example prompt
I am walking through the contract attached to the chat. How should I close them?

## Expected output shape
- how to frame the walkthrough
- what to emphasize
- agreement-check questions
- final close
- hesitation responses
